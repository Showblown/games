Hello guys this is skills gurukul
stop snooping why are you even here
